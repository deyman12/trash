<?php 
/**
 * define('PHP_BOLT_KEY', 'kyc7fh'); We want give key to client 
 */
define('PHP_BOLT_KEY', 'kyc7fh');
bolt_decrypt( __FILE__ , PHP_BOLT_KEY); return 0;
    ##!!!##i4psiIu8tLxssa+0u2xztLG4uLtsw7u+uLBzh2w=