<?php

if ($argc < 2) {
    die("usage: main.php <file.php>");
} else {

    include "Decompiler4.class.php";

    $realpath = realpath($argv[1]);
    $decode = new Decompiler(array("php"));
    $decode->decompileFile($realpath);

    ob_start();
    $decode->output();
    $string = ob_get_clean();
    print $string . PHP_EOL;

    $fname = str_replace(basename($realpath), "deo_" . basename($realpath), $realpath);
    file_put_contents(
        $fname,
        $string
    );
    print PHP_EOL . "saved as: $fname" . PHP_EOL;
}
