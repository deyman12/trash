<?php

require_once 'vendor/soap/lib/nusoap.php';
$domain = str_replace('www.', '', $_SERVER['HTTP_HOST']);
$client = new nusoap_client('http://softwaremillenium.com/webservice/licencia.php?wsdl');
$client2 = new nusoap_client('http://ricoycrujiente.com/webservicemillenium/licencia.php?wsdl');
$KEY_LICENCE = 'Y02PRiGlzQKuVwYNxr9MXzJI-QQuFXu_S477mTToaNg';
$result = $client->call('getLicenceStatus', array('idClient' => $KEY_LICENCE, 'domainName' => $domain));

if ($client->fault) {
	$result2 = $client2->call('getLicenceStatus', array('idClient' => $KEY_LICENCE, 'domainName' => $domain));

	if ($client2->fault) {
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
		echo '<h2>Problema de comunicación</h2><pre>Disculpe, si esta viendo este mensaje debe de haber un problema con esta instalación. Estos son algunos de los motivos.<ul><li>Puede que el hosting donde esta instalado esta licencia no esta permitiendo comunicarse con la plataforma "Millenium" (Couldn\'t open socket connection to server http://softwaremillenium.com/ prior to connect(). This is often a problem looking up the host name.)</li><li>El sistema ha enviado una solicitud a la plataforma Millenium pero al parecer hay un problema en la respuesta en la solicitud.</li></ul> Estos pueden ser algunos motivos del problema, por favor contacte con Soporte Millenium para solucionarlo.</pre>';
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
		exit();
	}
	else if ($err2) {
		echo '<h2>Error</h2><pre>Disculpe, si esta viendo este mensaje debe de haber un problema con esta instalación. Estos son algunos de los motivos.<ul><li>Puede que el hosting donde esta instalado esta licencia no esta permitiendo comunicarse con la plataforma "Millenium" (Couldn\'t open socket connection to server http://softwaremillenium.com/ prior to connect(). This is often a problem looking up the host name.)</li><li>El sistema ha enviado una solicitud a la plataforma Millenium pero al parecer hay un problema en la respuesta en la solicitud.</li></ul> Estos pueden ser algunos motivos del problema, por favor contacte con Soporte Millenium para solucionarlo.</pre>';
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
	}
	else {
		$_SESSION['LICENCIAMILLENIUMANGEL'] = $result2;
	}
}
else if ($err) {
	$result2 = $client2->call('getLicenceStatus', array('idClient' => $KEY_LICENCE, 'domainName' => $domain));

	if ($client2->fault) {
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
		echo '<h2>Error</h2><pre>Disculpe, si esta viendo este mensaje debe de haber un problema con esta instalación. Estos son algunos de los motivos.<ul><li>Puede que el hosting donde esta instalado esta licencia no esta permitiendo comunicarse con la plataforma "Millenium" (Couldn\'t open socket connection to server http://softwaremillenium.com/ prior to connect(). This is often a problem looking up the host name.)</li><li>El sistema ha enviado una solicitud a la plataforma Millenium pero al parecer hay un problema en la respuesta en la solicitud.</li></ul> Estos pueden ser algunos motivos del problema, por favor contacte con Soporte Millenium para solucionarlo.</pre>';
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
		exit();
	}
	else if ($err2) {
		echo '<h2>Error</h2><pre>Disculpe, si esta viendo este mensaje debe de haber un problema con esta instalación. Estos son algunos de los motivos.<ul><li>Puede que el hosting donde esta instalado esta licencia no esta permitiendo comunicarse con la plataforma "Millenium" (Couldn\'t open socket connection to server http://softwaremillenium.com/ prior to connect(). This is often a problem looking up the host name.)</li><li>El sistema ha enviado una solicitud a la plataforma Millenium pero al parecer hay un problema en la respuesta en la solicitud.</li></ul> Estos pueden ser algunos motivos del problema, por favor contacte con Soporte Millenium para solucionarlo.</pre>';
		unset($_SESSION['LICENCIAMILLENIUMANGEL']);
	}
	else {
		$_SESSION['LICENCIAMILLENIUMANGEL'] = $result2;
	}
}
else {
	$_SESSION['LICENCIAMILLENIUMANGEL'] = $result;
}

?>
